import type { Topic } from '@/types/quiz';
import { RotateCcw, Home, Trophy, Target, AlertCircle } from 'lucide-react';

interface QuizResultsProps {
  topic: Topic;
  correctCount: number;
  wrongCount: number;
  skippedCount: number;
  totalQuestions: number;
  onResetTopic: () => void;
  onGoHome: () => void;
}

export function QuizResults({
  topic,
  correctCount,
  wrongCount,
  skippedCount,
  totalQuestions,
  onResetTopic,
  onGoHome,
}: QuizResultsProps) {
  const percentage = Math.round((correctCount / totalQuestions) * 100);
  
  // Determine grade
  let grade: { label: string; class: string };
  if (percentage >= 80) {
    grade = { label: 'Distinction', class: 'grade-distinction' };
  } else if (percentage >= 60) {
    grade = { label: 'Pass', class: 'grade-pass' };
  } else {
    grade = { label: 'Needs Review', class: 'grade-review' };
  }

  // SVG ring chart calculations
  const radius = 80;
  const strokeWidth = 12;
  const normalizedRadius = radius - strokeWidth / 2;
  const circumference = normalizedRadius * 2 * Math.PI;
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  return (
    <div className="quiz-results">
      <div className="results-card">
        <h2 className="results-title">Topic Complete</h2>
        <p className="results-subtitle">{topic.title}</p>

        {/* SVG Ring Chart */}
        <div className="ring-chart-container">
          <svg
            width={radius * 2 + 40}
            height={radius * 2 + 40}
            className="ring-chart"
          >
            {/* Background circle */}
            <circle
              stroke="#e5e7eb"
              fill="transparent"
              strokeWidth={strokeWidth}
              r={normalizedRadius}
              cx={radius + 20}
              cy={radius + 20}
            />
            {/* Progress circle */}
            <circle
              stroke="#085041"
              fill="transparent"
              strokeWidth={strokeWidth}
              strokeDasharray={circumference + ' ' + circumference}
              style={{ strokeDashoffset, transition: 'stroke-dashoffset 0.5s ease-in-out' }}
              strokeLinecap="round"
              r={normalizedRadius}
              cx={radius + 20}
              cy={radius + 20}
            />
            {/* Percentage text */}
            <text
              x={radius + 20}
              y={radius + 10}
              textAnchor="middle"
              dominantBaseline="middle"
              className="ring-percentage"
            >
              {percentage}%
            </text>
            <text
              x={radius + 20}
              y={radius + 35}
              textAnchor="middle"
              dominantBaseline="middle"
              className="ring-label"
            >
              Score
            </text>
          </svg>
        </div>

        {/* Grade Pill */}
        <div className={`grade-pill ${grade.class}`}>
          {percentage >= 80 ? <Trophy className="w-4 h-4" /> : 
           percentage >= 60 ? <Target className="w-4 h-4" /> : 
           <AlertCircle className="w-4 h-4" />}
          {grade.label}
        </div>

        {/* Stats Grid */}
        <div className="stats-grid">
          <div className="stat-item stat-correct">
            <span className="stat-value">{correctCount}</span>
            <span className="stat-label">Correct</span>
          </div>
          <div className="stat-item stat-wrong">
            <span className="stat-value">{wrongCount}</span>
            <span className="stat-label">Wrong</span>
          </div>
          <div className="stat-item stat-skipped">
            <span className="stat-value">{skippedCount}</span>
            <span className="stat-label">Skipped</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="results-actions">
          <button className="btn-restart" onClick={onResetTopic}>
            <RotateCcw className="w-4 h-4" />
            Retake Topic
          </button>
          <button className="btn-home" onClick={onGoHome}>
            <Home className="w-4 h-4" />
            Dashboard
          </button>
        </div>
      </div>
    </div>
  );
}
