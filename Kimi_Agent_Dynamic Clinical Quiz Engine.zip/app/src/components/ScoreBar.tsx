import { CheckCircle2, XCircle, HelpCircle } from 'lucide-react';

interface ScoreBarProps {
  correctCount: number;
  wrongCount: number;
  remainingCount: number;
}

export function ScoreBar({ correctCount, wrongCount, remainingCount }: ScoreBarProps) {
  return (
    <div className="score-bar">
      <div className="score-chip correct-chip">
        <CheckCircle2 className="w-4 h-4" />
        <span className="score-label">Correct</span>
        <span className="score-value">{correctCount}</span>
      </div>
      <div className="score-chip wrong-chip">
        <XCircle className="w-4 h-4" />
        <span className="score-label">Wrong</span>
        <span className="score-value">{wrongCount}</span>
      </div>
      <div className="score-chip remaining-chip">
        <HelpCircle className="w-4 h-4" />
        <span className="score-label">Remaining</span>
        <span className="score-value">{remainingCount}</span>
      </div>
    </div>
  );
}
