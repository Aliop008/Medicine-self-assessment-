import type { Topic, TopicScore } from '@/types/quiz';
import {
  BookOpen,
  Trophy,
  TrendingUp,
  Award,
  Stethoscope,
  ShieldAlert,
  Bug,
  HeartPulse,
  Activity,
} from 'lucide-react';

interface HomeScreenProps {
  topics: Topic[];
  topicScores: Record<string, TopicScore>;
  onSelectTopic: (id: string) => void;
}

const topicGroups = [
  {
    label: 'Emergency & Environment',
    items: ['poisoning', 'envenomation', 'environmental', 'acute_critical'],
    icon: <ShieldAlert className="w-5 h-5" />,
    color: '#085041',
  },
  {
    label: 'Infectious Disease',
    items: ['principles_id', 'general_id', 'hiv_aids', 'stis'],
    icon: <Bug className="w-5 h-5" />,
    color: '#534AB7',
  },
  {
    label: 'Systemic Medicine',
    items: ['cardiology', 'respiratory', 'gastroenterology', 'hepatology', 'nephrology', 'neurology', 'stroke', 'haematology'],
    icon: <HeartPulse className="w-5 h-5" />,
    color: '#0F6E56',
  },
  {
    label: 'Metabolic & Endocrine',
    items: ['biochemistry', 'endocrinology', 'diabetes', 'nutrition'],
    icon: <Activity className="w-5 h-5" />,
    color: '#A32D2D',
  },
  {
    label: 'Specialties',
    items: ['rheumatology', 'psychiatry', 'dermatology'],
    icon: <Stethoscope className="w-5 h-5" />,
    color: '#633806',
  },
];

export function HomeScreen({ topics, topicScores, onSelectTopic }: HomeScreenProps) {
  const topicMap = new Map(topics.map(t => [t.id, t]));

  const completedCount = Object.values(topicScores).filter(s => s.completed).length;
  const totalCorrect = Object.values(topicScores).reduce((sum, s) => sum + s.correctCount, 0);
  const totalAnswered = Object.values(topicScores).reduce((sum, s) => sum + s.correctCount + s.wrongCount + s.skippedCount, 0);
  const overallAccuracy = totalAnswered > 0 ? Math.round((totalCorrect / totalAnswered) * 100) : 0;

  return (
    <div className="home-screen">
      {/* Hero */}
      <div className="home-hero">
        <div className="home-hero-circles">
          <div className="hero-circle circle-1" />
          <div className="hero-circle circle-2" />
          <div className="hero-circle circle-3" />
        </div>
        <div className="home-hero-content">
          <Stethoscope className="w-10 h-10 hero-icon" />
          <h1 className="home-title">Davidson's Self-Assessment</h1>
          <p className="home-subtitle">Master your medical knowledge across 23 clinical domains</p>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="home-stats">
        <div className="home-stat-card">
          <BookOpen className="w-5 h-5" />
          <span className="home-stat-value">{topics.length}</span>
          <span className="home-stat-label">Topics</span>
        </div>
        <div className="home-stat-card">
          <Trophy className="w-5 h-5" />
          <span className="home-stat-value">{completedCount}</span>
          <span className="home-stat-label">Completed</span>
        </div>
        <div className="home-stat-card">
          <TrendingUp className="w-5 h-5" />
          <span className="home-stat-value">{overallAccuracy}%</span>
          <span className="home-stat-label">Accuracy</span>
        </div>
        <div className="home-stat-card">
          <Award className="w-5 h-5" />
          <span className="home-stat-value">{totalCorrect}</span>
          <span className="home-stat-label">Correct</span>
        </div>
      </div>

      {/* Topic Groups */}
      <div className="home-groups">
        {topicGroups.map(group => (
          <div key={group.label} className="home-group">
            <div className="home-group-header" style={{ borderLeftColor: group.color }}>
              {group.icon}
              <h2>{group.label}</h2>
            </div>
            <div className="home-topic-grid">
              {group.items.map(topicId => {
                const topic = topicMap.get(topicId);
                if (!topic) return null;
                const score = topicScores[topicId];
                const isCompleted = score?.completed;
                const progress = topic.questions.length > 0 && score
                  ? Math.round(((score.correctCount + score.wrongCount + score.skippedCount) / topic.questions.length) * 100)
                  : 0;

                return (
                  <button
                    key={topicId}
                    className={`home-topic-card ${isCompleted ? 'completed' : ''}`}
                    onClick={() => onSelectTopic(topicId)}
                  >
                    <div className="home-topic-header">
                      <span className="home-topic-title">{topic.title}</span>
                      {isCompleted && <Trophy className="w-4 h-4 trophy-icon" />}
                    </div>
                    <div className="home-topic-meta">
                      <span>{topic.questions.length} questions</span>
                      {score && (
                        <span className="home-topic-score">
                          {score.correctCount}/{topic.questions.length} correct
                        </span>
                      )}
                    </div>
                    <div className="home-topic-progress-bar">
                      <div
                        className="home-topic-progress-fill"
                        style={{
                          width: `${progress}%`,
                          backgroundColor: isCompleted ? '#1D9E75' : '#534AB7',
                        }}
                      />
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
