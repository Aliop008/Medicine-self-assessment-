import { useState } from 'react';
import type { Topic, TopicScore } from '@/types/quiz';
import {
  Stethoscope,
  ChevronLeft,
  ChevronRight,
  Home,
  Activity,
  Bug,
  HeartPulse,
  Wind,
  Brain,
  Droplets,
  Flame,
  Dna,
  Syringe,
  Pill,
  Bone,
  CircleDot,
  Microscope,
  ShieldAlert,
  Trees,
  UserCircle,
  Sparkles,
  CheckCircle2,
  Circle,
} from 'lucide-react';

interface SidebarProps {
  topics: Topic[];
  currentTopicId: string | null;
  topicScores: Record<string, TopicScore>;
  onSelectTopic: (id: string) => void;
  onGoHome: () => void;
}

const topicGroups = [
  {
    label: 'Emergency & Environment',
    items: ['poisoning', 'envenomation', 'environmental', 'acute_critical'],
    icon: <ShieldAlert className="w-4 h-4" />,
  },
  {
    label: 'Infectious Disease',
    items: ['principles_id', 'general_id', 'hiv_aids', 'stis'],
    icon: <Bug className="w-4 h-4" />,
  },
  {
    label: 'Systemic Medicine',
    items: ['cardiology', 'respiratory', 'gastroenterology', 'hepatology', 'nephrology', 'neurology', 'stroke', 'haematology'],
    icon: <HeartPulse className="w-4 h-4" />,
  },
  {
    label: 'Metabolic & Endocrine',
    items: ['biochemistry', 'endocrinology', 'diabetes', 'nutrition'],
    icon: <Activity className="w-4 h-4" />,
  },
  {
    label: 'Specialties',
    items: ['rheumatology', 'psychiatry', 'dermatology'],
    icon: <Stethoscope className="w-4 h-4" />,
  },
];

const topicIcons: Record<string, React.ReactNode> = {
  poisoning: <Flame className="w-4 h-4" />,
  envenomation: <Bug className="w-4 h-4" />,
  environmental: <Trees className="w-4 h-4" />,
  acute_critical: <ShieldAlert className="w-4 h-4" />,
  principles_id: <Microscope className="w-4 h-4" />,
  general_id: <Bug className="w-4 h-4" />,
  hiv_aids: <Dna className="w-4 h-4" />,
  stis: <UserCircle className="w-4 h-4" />,
  cardiology: <HeartPulse className="w-4 h-4" />,
  respiratory: <Wind className="w-4 h-4" />,
  gastroenterology: <Activity className="w-4 h-4" />,
  hepatology: <Sparkles className="w-4 h-4" />,
  nephrology: <Droplets className="w-4 h-4" />,
  neurology: <Brain className="w-4 h-4" />,
  stroke: <CircleDot className="w-4 h-4" />,
  haematology: <Droplets className="w-4 h-4" />,
  biochemistry: <Microscope className="w-4 h-4" />,
  endocrinology: <Activity className="w-4 h-4" />,
  diabetes: <Syringe className="w-4 h-4" />,
  nutrition: <Pill className="w-4 h-4" />,
  rheumatology: <Bone className="w-4 h-4" />,
  psychiatry: <Brain className="w-4 h-4" />,
  dermatology: <UserCircle className="w-4 h-4" />,
};

export function Sidebar({ topics, currentTopicId, topicScores, onSelectTopic, onGoHome }: SidebarProps) {
  const [collapsed, setCollapsed] = useState(false);
  const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>({
    'Emergency & Environment': true,
    'Infectious Disease': true,
    'Systemic Medicine': true,
    'Metabolic & Endocrine': true,
    'Specialties': true,
  });

  const toggleGroup = (label: string) => {
    setExpandedGroups(prev => ({ ...prev, [label]: !prev[label] }));
  };

  const topicMap = new Map(topics.map(t => [t.id, t]));

  return (
    <aside className={`sidebar ${collapsed ? 'collapsed' : ''}`}>
      <div className="sidebar-header">
        {!collapsed && (
          <div className="sidebar-brand" onClick={onGoHome}>
            <Stethoscope className="w-6 h-6" />
            <div className="sidebar-brand-text">
              <span className="sidebar-brand-title">Davidson's</span>
              <span className="sidebar-brand-sub">Self-Assessment</span>
            </div>
          </div>
        )}
        <button
          className="sidebar-toggle"
          onClick={() => setCollapsed(!collapsed)}
          aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </div>

      <nav className="sidebar-nav">
        <button
          className={`sidebar-home-btn ${!currentTopicId ? 'active' : ''}`}
          onClick={onGoHome}
        >
          <Home className="w-4 h-4" />
          {!collapsed && <span>Dashboard</span>}
        </button>

        {!collapsed && (
          <div className="sidebar-sections">
            {topicGroups.map(group => (
              <div key={group.label} className="sidebar-group">
                <button
                  className="sidebar-group-header"
                  onClick={() => toggleGroup(group.label)}
                >
                  {group.icon}
                  <span>{group.label}</span>
                  {expandedGroups[group.label] ? (
                    <ChevronLeft className="w-3 h-3 rotate-90" />
                  ) : (
                    <ChevronRight className="w-3 h-3 rotate-90" />
                  )}
                </button>
                {expandedGroups[group.label] && (
                  <div className="sidebar-group-items">
                    {group.items.map(topicId => {
                      const topic = topicMap.get(topicId);
                      if (!topic) return null;
                      const score = topicScores[topicId];
                      const isActive = currentTopicId === topicId;
                      return (
                        <button
                          key={topicId}
                          className={`sidebar-topic-btn ${isActive ? 'active' : ''}`}
                          onClick={() => onSelectTopic(topicId)}
                        >
                          {topicIcons[topicId] || <Circle className="w-4 h-4" />}
                          <span className="sidebar-topic-name">{topic.title}</span>
                          {score?.completed && (
                            <CheckCircle2 className="w-3 h-3 completed-icon" />
                          )}
                          {!score?.completed && score && (
                            <span className="sidebar-topic-progress">
                              {score.correctCount}/{topic.questions.length}
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {collapsed && (
          <div className="sidebar-collapsed-icons">
            {topics.map(topic => {
              const score = topicScores[topic.id];
              const isActive = currentTopicId === topic.id;
              return (
                <button
                  key={topic.id}
                  className={`sidebar-collapsed-btn ${isActive ? 'active' : ''}`}
                  onClick={() => onSelectTopic(topic.id)}
                  title={topic.title}
                >
                  {topicIcons[topic.id] || <Circle className="w-4 h-4" />}
                  {score?.completed && (
                    <span className="sidebar-collapsed-dot" />
                  )}
                </button>
              );
            })}
          </div>
        )}
      </nav>
    </aside>
  );
}
