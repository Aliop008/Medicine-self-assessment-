import type { Question } from '@/types/quiz';
import { HelpCircle, Lightbulb, SkipForward, Send, ArrowRight } from 'lucide-react';

interface QuestionCardProps {
  question: Question;
  selectedAnswer: string | null;
  isSubmitted: boolean;
  showHint: boolean;
  onSelectAnswer: (answer: string) => void;
  onSubmit: () => void;
  onToggleHint: () => void;
  onSkip: () => void;
  onNext: () => void;
}

export function QuestionCard({
  question,
  selectedAnswer,
  isSubmitted,
  showHint,
  onSelectAnswer,
  onSubmit,
  onToggleHint,
  onSkip,
  onNext,
}: QuestionCardProps) {
  const optionLetters = Object.keys(question.options).sort();

  const getOptionClass = (letter: string) => {
    const base = 'option-row';
    if (!isSubmitted) {
      if (selectedAnswer === letter) return `${base} selected`;
      return base;
    }
    // Submitted state
    if (letter === question.correctAnswer) {
      return `${base} correct`;
    }
    if (selectedAnswer === letter && letter !== question.correctAnswer) {
      return `${base} wrong`;
    }
    return `${base} disabled`;
  };

  const getBadgeClass = (letter: string) => {
    const base = 'option-badge';
    if (!isSubmitted) {
      if (selectedAnswer === letter) return `${base} badge-selected`;
      return `${base} badge-default`;
    }
    if (letter === question.correctAnswer) {
      return `${base} badge-correct`;
    }
    if (selectedAnswer === letter && letter !== question.correctAnswer) {
      return `${base} badge-wrong`;
    }
    return `${base} badge-default`;
  };

  return (
    <div className="question-card">
      {/* Question Text */}
      <div className="question-text-container">
        <p className="question-text">{question.question}</p>
      </div>

      {/* Options */}
      <div className="options-list">
        {optionLetters.map(letter => (
          <button
            key={letter}
            className={getOptionClass(letter)}
            onClick={() => !isSubmitted && onSelectAnswer(letter)}
            disabled={isSubmitted}
          >
            <span className={getBadgeClass(letter)}>{letter}</span>
            <span className="option-text">{question.options[letter]}</span>
          </button>
        ))}
      </div>

      {/* Hint Box */}
      {showHint && !isSubmitted && (
        <div className="hint-box">
          <div className="hint-icon-wrapper">
            <HelpCircle className="w-5 h-5" />
          </div>
          <p className="hint-text">{question.hint}</p>
        </div>
      )}

      {/* Explanation Box */}
      {isSubmitted && (
        <div className={`explanation-box ${selectedAnswer === question.correctAnswer ? 'correct' : 'wrong'}`}>
          <div className="explanation-header">
            {selectedAnswer === question.correctAnswer ? (
              <>
                <span className="explanation-icon correct">✓</span>
                <span className="explanation-title">Correct Answer</span>
              </>
            ) : (
              <>
                <span className="explanation-icon wrong">✗</span>
                <span className="explanation-title">Incorrect</span>
                <span className="explanation-correct">
                  Correct: {question.correctAnswer}
                </span>
              </>
            )}
          </div>
          <p className="explanation-text">{question.explanation}</p>
        </div>
      )}

      {/* Action Buttons */}
      <div className="action-buttons">
        {!isSubmitted ? (
          <>
            <button
              className="btn-hint"
              onClick={onToggleHint}
            >
              <Lightbulb className="w-4 h-4" />
              {showHint ? 'Hide Hint' : 'Show Hint'}
            </button>
            <button
              className="btn-skip"
              onClick={onSkip}
            >
              <SkipForward className="w-4 h-4" />
              Skip
            </button>
            <button
              className={`btn-submit ${selectedAnswer ? 'active' : ''}`}
              onClick={onSubmit}
              disabled={!selectedAnswer}
            >
              <Send className="w-4 h-4" />
              Submit
            </button>
          </>
        ) : (
          <button
            className="btn-next"
            onClick={onNext}
          >
            Next Question
            <ArrowRight className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
}
