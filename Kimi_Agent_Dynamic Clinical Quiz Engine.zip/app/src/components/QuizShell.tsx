import type { Topic, Question } from '@/types/quiz';
import { ScoreBar } from './ScoreBar';
import { QuestionCard } from './QuestionCard';
import { QuizResults } from './QuizResults';
import { ProgressBar } from './ProgressBar';
import { ArrowLeft, RotateCcw } from 'lucide-react';

interface QuizShellProps {
  topic: Topic;
  question: Question | null;
  questionIndex: number;
  totalQuestions: number;
  selectedAnswer: string | null;
  isSubmitted: boolean;
  showHint: boolean;
  correctCount: number;
  wrongCount: number;
  remainingCount: number;
  isComplete: boolean;
  answeredQuestions: Set<number>;
  onSelectAnswer: (answer: string) => void;
  onSubmit: () => void;
  onToggleHint: () => void;
  onSkip: () => void;
  onNext: () => void;
  onGoToQuestion: (index: number) => void;
  onResetTopic: (id: string) => void;
  onGoHome: () => void;
}

export function QuizShell({
  topic,
  question,
  questionIndex,
  totalQuestions,
  selectedAnswer,
  isSubmitted,
  showHint,
  correctCount,
  wrongCount,
  remainingCount,
  isComplete,
  answeredQuestions,
  onSelectAnswer,
  onSubmit,
  onToggleHint,
  onSkip,
  onNext,
  onGoToQuestion,
  onResetTopic,
  onGoHome,
}: QuizShellProps) {
  if (isComplete) {
    return (
      <QuizResults
        topic={topic}
        correctCount={correctCount}
        wrongCount={wrongCount}
        skippedCount={totalQuestions - correctCount - wrongCount}
        totalQuestions={totalQuestions}
        onResetTopic={() => onResetTopic(topic.id)}
        onGoHome={onGoHome}
      />
    );
  }

  if (!question) return null;

  const progress = ((answeredQuestions.size) / totalQuestions) * 100;

  return (
    <div className="quiz-shell">
      {/* Header */}
      <div className="quiz-header">
        <div className="quiz-header-circles">
          <div className="header-circle circle-1" />
          <div className="header-circle circle-2" />
          <div className="header-circle circle-3" />
        </div>
        <div className="quiz-header-content">
          <button className="quiz-back-btn" onClick={onGoHome}>
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div className="quiz-header-info">
            <h1 className="quiz-topic-title">{topic.title}</h1>
            <span className="quiz-question-counter">
              Question {questionIndex + 1} of {totalQuestions}
            </span>
          </div>
          <button
            className="quiz-reset-btn"
            onClick={() => onResetTopic(topic.id)}
            title="Restart topic"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Score Bar */}
      <ScoreBar
        correctCount={correctCount}
        wrongCount={wrongCount}
        remainingCount={remainingCount}
      />

      {/* Progress Bar */}
      <ProgressBar progress={progress} />

      {/* Question Navigator */}
      <div className="question-navigator">
        {Array.from({ length: totalQuestions }, (_, i) => (
          <button
            key={i}
            className={`nav-dot ${
              i === questionIndex
                ? 'active'
                : answeredQuestions.has(i)
                ? 'answered'
                : ''
            }`}
            onClick={() => onGoToQuestion(i)}
            title={`Question ${i + 1}`}
          />
        ))}
      </div>

      {/* Question Card */}
      <QuestionCard
        question={question}
        selectedAnswer={selectedAnswer}
        isSubmitted={isSubmitted}
        showHint={showHint}
        onSelectAnswer={onSelectAnswer}
        onSubmit={onSubmit}
        onToggleHint={onToggleHint}
        onSkip={onSkip}
        onNext={onNext}
      />
    </div>
  );
}
