export interface Question {
  id: string;
  number: number;
  question: string;
  options: Record<string, string>;
  correctAnswer: string;
  explanation: string;
  hint: string;
}

export interface Topic {
  id: string;
  title: string;
  questions: Question[];
}

export interface QuizState {
  currentTopicId: string | null;
  currentQuestionIndex: number;
  selectedAnswer: string | null;
  isSubmitted: boolean;
  showHint: boolean;
  correctCount: number;
  wrongCount: number;
  skippedCount: number;
  answeredQuestions: Set<number>;
  topicScores: Record<string, TopicScore>;
}

export interface TopicScore {
  topicId: string;
  topicTitle: string;
  totalQuestions: number;
  correctCount: number;
  wrongCount: number;
  skippedCount: number;
  completed: boolean;
  completedAt: string | null;
}

export type AnswerState = 'unselected' | 'selected' | 'correct' | 'wrong';
