import { useQuizData } from '@/hooks/useQuizData';
import { Sidebar } from '@/components/Sidebar';
import { QuizShell } from '@/components/QuizShell';
import { HomeScreen } from '@/components/HomeScreen';
import './App.css';

function App() {
  const {
    topics,
    loading,
    state,
    currentTopic,
    currentQuestion,
    totalQuestions,
    remainingCount,
    isComplete,
    selectTopic,
    selectAnswer,
    submitAnswer,
    toggleHint,
    skipQuestion,
    nextQuestion,
    goToQuestion,
    resetTopic,
    goHome,
  } = useQuizData();

  if (loading) {
    return (
      <div className="loading-screen">
        <div className="loading-spinner" />
        <p>Loading assessment data...</p>
      </div>
    );
  }

  return (
    <div className="app-container">
      <Sidebar
        topics={topics}
        currentTopicId={state.currentTopicId}
        topicScores={state.topicScores}
        onSelectTopic={selectTopic}
        onGoHome={goHome}
      />
      <main className="main-content">
        {!currentTopic ? (
          <HomeScreen
            topics={topics}
            topicScores={state.topicScores}
            onSelectTopic={selectTopic}
          />
        ) : (
          <QuizShell
            topic={currentTopic}
            question={currentQuestion}
            questionIndex={state.currentQuestionIndex}
            totalQuestions={totalQuestions}
            selectedAnswer={state.selectedAnswer}
            isSubmitted={state.isSubmitted}
            showHint={state.showHint}
            correctCount={state.correctCount}
            wrongCount={state.wrongCount}
            remainingCount={remainingCount}
            isComplete={isComplete}
            answeredQuestions={state.answeredQuestions}
            onSelectAnswer={selectAnswer}
            onSubmit={submitAnswer}
            onToggleHint={toggleHint}
            onSkip={skipQuestion}
            onNext={nextQuestion}
            onGoToQuestion={goToQuestion}
            onResetTopic={resetTopic}
            onGoHome={goHome}
          />
        )}
      </main>
    </div>
  );
}

export default App;
