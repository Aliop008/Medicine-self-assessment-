import { useState, useEffect, useCallback } from 'react';
import type { Topic, QuizState, TopicScore } from '@/types/quiz';

const STORAGE_KEY = 'davidson_quiz_scores';

const initialState: QuizState = {
  currentTopicId: null,
  currentQuestionIndex: 0,
  selectedAnswer: null,
  isSubmitted: false,
  showHint: false,
  correctCount: 0,
  wrongCount: 0,
  skippedCount: 0,
  answeredQuestions: new Set(),
  topicScores: {},
};

function loadScoresFromStorage(): Record<string, TopicScore> {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      // Convert answeredIndices back to Set if they exist
      return parsed;
    }
  } catch {
    // ignore
  }
  return {};
}

function saveScoresToStorage(scores: Record<string, TopicScore>) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(scores));
  } catch {
    // ignore
  }
}

export function useQuizData() {
  const [topics, setTopics] = useState<Topic[]>([]);
  const [state, setState] = useState<QuizState>(initialState);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const scores = loadScoresFromStorage();
    setState(prev => ({ ...prev, topicScores: scores }));

    fetch('/data/quiz_data.json')
      .then(res => res.json())
      .then((data: Record<string, Topic>) => {
        const topicList = Object.values(data);
        setTopics(topicList);
        setLoading(false);
      })
      .catch(err => {
        console.error('Failed to load quiz data:', err);
        setLoading(false);
      });
  }, []);

  const selectTopic = useCallback((topicId: string) => {
    setState(prev => ({
      ...prev,
      currentTopicId: topicId,
      currentQuestionIndex: 0,
      selectedAnswer: null,
      isSubmitted: false,
      showHint: false,
      correctCount: 0,
      wrongCount: 0,
      skippedCount: 0,
      answeredQuestions: new Set(),
    }));
  }, []);

  const selectAnswer = useCallback((answer: string) => {
    setState(prev => {
      if (prev.isSubmitted) return prev;
      return { ...prev, selectedAnswer: answer };
    });
  }, []);

  const submitAnswer = useCallback(() => {
    setState(prev => {
      if (!prev.selectedAnswer || prev.isSubmitted) return prev;
      
      const topic = topics.find(t => t.id === prev.currentTopicId);
      if (!topic) return prev;
      
      const question = topic.questions[prev.currentQuestionIndex];
      const isCorrect = prev.selectedAnswer === question.correctAnswer;
      
      const newAnswered = new Set(prev.answeredQuestions);
      newAnswered.add(prev.currentQuestionIndex);
      
      return {
        ...prev,
        isSubmitted: true,
        correctCount: isCorrect ? prev.correctCount + 1 : prev.correctCount,
        wrongCount: isCorrect ? prev.wrongCount : prev.wrongCount + 1,
        answeredQuestions: newAnswered,
      };
    });
  }, [topics]);

  const toggleHint = useCallback(() => {
    setState(prev => ({ ...prev, showHint: !prev.showHint }));
  }, []);

  const skipQuestion = useCallback(() => {
    setState(prev => {
      const topic = topics.find(t => t.id === prev.currentTopicId);
      if (!topic) return prev;

      const newAnswered = new Set(prev.answeredQuestions);
      newAnswered.add(prev.currentQuestionIndex);

      const isLast = prev.currentQuestionIndex >= topic.questions.length - 1;
      
      if (isLast) {
        // Save score
        const newScores = { ...prev.topicScores };
        newScores[topic.id] = {
          topicId: topic.id,
          topicTitle: topic.title,
          totalQuestions: topic.questions.length,
          correctCount: prev.correctCount,
          wrongCount: prev.wrongCount,
          skippedCount: prev.skippedCount + 1,
          completed: true,
          completedAt: new Date().toISOString(),
        };
        saveScoresToStorage(newScores);
        
        return {
          ...prev,
          skippedCount: prev.skippedCount + 1,
          answeredQuestions: newAnswered,
          topicScores: newScores,
        };
      }
      
      return {
        ...prev,
        currentQuestionIndex: prev.currentQuestionIndex + 1,
        selectedAnswer: null,
        isSubmitted: false,
        showHint: false,
        skippedCount: prev.skippedCount + 1,
        answeredQuestions: newAnswered,
      };
    });
  }, [topics]);

  const nextQuestion = useCallback(() => {
    setState(prev => {
      const topic = topics.find(t => t.id === prev.currentTopicId);
      if (!topic) return prev;

      const newAnswered = new Set(prev.answeredQuestions);
      newAnswered.add(prev.currentQuestionIndex);

      const isLast = prev.currentQuestionIndex >= topic.questions.length - 1;
      
      if (isLast) {
        // Save score
        const newScores = { ...prev.topicScores };
        newScores[topic.id] = {
          topicId: topic.id,
          topicTitle: topic.title,
          totalQuestions: topic.questions.length,
          correctCount: prev.correctCount,
          wrongCount: prev.wrongCount,
          skippedCount: prev.skippedCount,
          completed: true,
          completedAt: new Date().toISOString(),
        };
        saveScoresToStorage(newScores);
        
        return {
          ...prev,
          answeredQuestions: newAnswered,
          topicScores: newScores,
        };
      }
      
      return {
        ...prev,
        currentQuestionIndex: prev.currentQuestionIndex + 1,
        selectedAnswer: null,
        isSubmitted: false,
        showHint: false,
        answeredQuestions: newAnswered,
      };
    });
  }, [topics]);

  const goToQuestion = useCallback((index: number) => {
    setState(prev => {
      if (prev.answeredQuestions.has(index)) return prev;
      return {
        ...prev,
        currentQuestionIndex: index,
        selectedAnswer: null,
        isSubmitted: false,
        showHint: false,
      };
    });
  }, []);

  const resetTopic = useCallback((topicId: string) => {
    setState(prev => {
      const newScores = { ...prev.topicScores };
      delete newScores[topicId];
      saveScoresToStorage(newScores);
      
      return {
        ...initialState,
        currentTopicId: topicId,
        topicScores: newScores,
      };
    });
  }, []);

  const goHome = useCallback(() => {
    setState(prev => ({
      ...initialState,
      topicScores: prev.topicScores,
    }));
  }, []);

  const currentTopic = topics.find(t => t.id === state.currentTopicId) || null;
  const currentQuestion = currentTopic?.questions[state.currentQuestionIndex] || null;
  const totalQuestions = currentTopic?.questions.length || 0;
  const remainingCount = totalQuestions - state.answeredQuestions.size;
  const isComplete = totalQuestions > 0 && state.answeredQuestions.size >= totalQuestions;

  return {
    topics,
    loading,
    state,
    currentTopic,
    currentQuestion,
    totalQuestions,
    remainingCount,
    isComplete,
    selectTopic,
    selectAnswer,
    submitAnswer,
    toggleHint,
    skipQuestion,
    nextQuestion,
    goToQuestion,
    resetTopic,
    goHome,
  };
}
